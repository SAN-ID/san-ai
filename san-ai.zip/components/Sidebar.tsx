
// Sidebar removed to satisfy "single page, no menu" requirement.
export default null;
