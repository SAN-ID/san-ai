
// File removed in favor of streamlined ChatView.tsx
